#pragma once

#include "oqpi/parallel_algorithms/simple_partitioner.hpp"
#include "oqpi/parallel_algorithms/atomic_partitioner.hpp"
//#include "oqpi/parallel_algorithms/mutable_atomic_partitioner.hpp"
#include "oqpi/parallel_algorithms/parallel_for.hpp"
